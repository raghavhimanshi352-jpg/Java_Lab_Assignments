// Name: Himanshi Raghav
// Roll Number: [Enter your roll number]
// Assignment 09 - Matrices Rows and Columns
// Task 3

public class Main {
    public static void main(String[] args) {
        int[][] m = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        int count = 0;
        for (int[] row : m) {
            for (int value : row) {
                if (value > 5) count++;
            }
        }
        System.out.println("Values greater than 5: " + count);
    }
}
