// Name: Himanshi Raghav
// Roll Number: [Enter your roll number]
// Assignment 09 - Matrices Rows and Columns
// Task 2

public class Main {
    public static void main(String[] args) {
        int[][] m = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        for (int col = 0; col < 3; col++) {
            int sum = 0;
            for (int row = 0; row < 3; row++) sum += m[row][col];
            System.out.println("Column " + (col + 1) + " sum: " + sum);
        }
    }
}
