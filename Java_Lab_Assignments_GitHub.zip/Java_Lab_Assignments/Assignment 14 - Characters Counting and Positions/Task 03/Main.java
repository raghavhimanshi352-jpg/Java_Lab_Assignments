// Name: Himanshi Raghav
// Roll Number: [Enter your roll number]
// Assignment 14 - Characters Counting and Positions
// Task 3

public class Main {
    public static void main(String[] args) {
        String s = "hello";
        for (int i = 0; i < s.length(); i++) {
            System.out.println(i + ": " + s.charAt(i));
        }
    }
}
