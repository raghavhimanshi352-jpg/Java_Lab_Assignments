// Name: Himanshi Raghav
// Roll Number: [Enter your roll number]
// Assignment 07 - Counting Steps and Complexity
// Task 1

public class Main {
    public static void main(String[] args) {
        int steps = 0;
        // Time complexity: O(n)
        for (int i = 1; i <= 10; i++) {
            steps++;
        }
        System.out.println("Steps: " + steps);
    }
}
