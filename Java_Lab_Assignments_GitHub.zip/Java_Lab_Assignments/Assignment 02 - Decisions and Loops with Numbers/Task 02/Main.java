// Name: Himanshi Raghav
// Roll Number: [Enter your roll number]
// Assignment 02 - Decisions and Loops with Numbers
// Task 2

public class Main {
    public static void main(String[] args) {
        int marks = 83;
        if (marks >= 90) {
            System.out.println("Grade: A");
        } else if (marks >= 75) {
            System.out.println("Grade: B");
        } else {
            System.out.println("Grade: C");
        }
    }
}
