// Name: Himanshi Raghav
// Roll Number: [Enter your roll number]
// Assignment 02 - Decisions and Loops with Numbers
// Task 1

public class Main {
    public static void main(String[] args) {
        int n = 27;
        if (n % 2 == 0) {
            System.out.println(n + " is even");
        } else {
            System.out.println(n + " is odd");
        }
    }
}
