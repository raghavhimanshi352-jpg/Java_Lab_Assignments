// Name: Himanshi Raghav
// Roll Number: [Enter your roll number]
// Assignment 13 - Strings Methods and Palindromes
// Task 2

public class Main {
    public static void main(String[] args) {
        String word = "Java";
        String reversed = "";
        for (int i = 0; i < word.length(); i++) {
            reversed = word.charAt(i) + reversed;
        }
        System.out.println("Reversed: " + reversed);
    }
}
