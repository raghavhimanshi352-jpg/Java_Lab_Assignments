// Name: Himanshi Raghav
// Roll Number: [Enter your roll number]
// Assignment 13 - Strings Methods and Palindromes
// Task 1

public class Main {
    public static void main(String[] args) {
        String word = "Programming";
        System.out.println("Length: " + word.length());
        System.out.println("Position of g: " + word.indexOf('g'));
        System.out.println("Upper case: " + word.toUpperCase());
    }
}
