// Name: Himanshi Raghav
// Roll Number: [Enter your roll number]
// Assignment 04 - Writing Functions
// Task 3

public class Main {
    static int maxOf(int a, int b) {
        return (a > b) ? a : b;
    }

    public static void main(String[] args) {
        System.out.println("Larger: " + maxOf(14, 9));
    }
}
