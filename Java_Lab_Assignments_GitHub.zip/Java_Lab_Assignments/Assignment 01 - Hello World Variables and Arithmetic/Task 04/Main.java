// Name: Himanshi Raghav
// Roll Number: [Enter your roll number]
// Assignment 01 - Hello World Variables and Arithmetic
// Task 4

public class Main {
    public static void main(String[] args) {
        final double PI = 3.14;
        double radius = 7;
        double area = PI * radius * radius;
        double perimeter = 2 * PI * radius;

        System.out.printf("Area: %.2f%n", area);
        System.out.printf("Perimeter: %.2f%n", perimeter);
    }
}
