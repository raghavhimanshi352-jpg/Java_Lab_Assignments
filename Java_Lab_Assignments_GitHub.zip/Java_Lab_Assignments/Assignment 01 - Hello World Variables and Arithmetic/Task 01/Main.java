// Name: Himanshi Raghav
// Roll Number: [Enter your roll number]
// Assignment 01 - Hello World Variables and Arithmetic
// Task 1

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello World");
        System.out.println("Welcome to Java");
    }
}
