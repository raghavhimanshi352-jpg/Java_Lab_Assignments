// Name: Himanshi Raghav
// Roll Number: [Enter your roll number]
// Assignment 01 - Hello World Variables and Arithmetic
// Task 3

public class Main {
    public static void main(String[] args) {
        int a = 17, b = 5;
        System.out.println("Sum: " + (a + b));
        System.out.println("Difference: " + (a - b));
        System.out.println("Product: " + (a * b));
        System.out.println("Quotient: " + (a / b));
        System.out.println("Remainder: " + (a % b));
    }
}
