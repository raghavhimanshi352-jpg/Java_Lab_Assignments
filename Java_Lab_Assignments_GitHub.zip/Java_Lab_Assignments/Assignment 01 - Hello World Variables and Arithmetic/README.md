# Assignment 01 - Hello World Variables and Arithmetic

Each task is in a separate folder and contains `Main.java` and `output.txt`.
Before submission, replace `[Enter your roll number]` in each Java file with your actual roll number, run the program, and save your own output screenshot if required by your teacher.
