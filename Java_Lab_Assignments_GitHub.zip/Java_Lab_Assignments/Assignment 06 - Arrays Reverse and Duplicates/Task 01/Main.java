// Name: Himanshi Raghav
// Roll Number: [Enter your roll number]
// Assignment 06 - Arrays Reverse and Duplicates
// Task 1

public class Main {
    public static void main(String[] args) {
        int[] arr = {10, 20, 30, 40, 50};
        for (int i = arr.length - 1; i >= 0; i--) {
            System.out.println(arr[i]);
        }
    }
}
