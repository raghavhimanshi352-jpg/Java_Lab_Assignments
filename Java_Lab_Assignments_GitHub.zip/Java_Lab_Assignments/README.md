# Invertis University - Programming in Java Lab Assignments

**Student:** Himanshi Raghav  
**Course:** BCA AI - First Year  
**Subject:** Programming in Java Lab (BCAICC153)  
**Roll Number:** [Enter your roll number]

This repository contains all 15 Java lab assignments (49 individual tasks) based on the assignment sheet.

## How to run a task
1. Open the required task folder.
2. Open `Main.java`.
3. Replace the roll-number placeholder in the comments with your actual roll number.
4. Compile and run:
   ```bash
   javac Main.java
   java Main
   ```
5. Compare your output with `output.txt`. Take a screenshot of your actual run if your instructor asks for it.

## Folder structure
Each assignment has its own folder. Every task has a separate `Main.java` file and an `output.txt` containing the expected output.

**Note:** The assignment sheet asks for one Java file per task with class name `Main`. Therefore, each task is kept in a separate folder so that all files can use the required class name without conflicts.
