// Name: Himanshi Raghav
// Roll Number: [Enter your roll number]
// Assignment 15 - StringBuilder Methods
// Task 1

public class Main {
    public static void main(String[] args) {
        StringBuilder sb = new StringBuilder("Hello");
        sb.append(" World");
        System.out.println(sb);
        System.out.println("Length: " + sb.length());
    }
}
