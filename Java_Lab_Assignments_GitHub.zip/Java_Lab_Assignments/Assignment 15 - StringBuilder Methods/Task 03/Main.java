// Name: Himanshi Raghav
// Roll Number: [Enter your roll number]
// Assignment 15 - StringBuilder Methods
// Task 3

public class Main {
    public static void main(String[] args) {
        StringBuilder sb = new StringBuilder("Java");
        sb.insert(0, "Hello ");
        System.out.println(sb);
    }
}
