// Name: Himanshi Raghav
// Roll Number: [Enter your roll number]
// Assignment 08 - Matrices Transpose and Row Sums
// Task 2

public class Main {
    public static void main(String[] args) {
        int[][] m = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        for (int col = 0; col < 3; col++) {
            for (int row = 0; row < 3; row++) {
                System.out.print(m[row][col] + " ");
            }
            System.out.println();
        }
    }
}
