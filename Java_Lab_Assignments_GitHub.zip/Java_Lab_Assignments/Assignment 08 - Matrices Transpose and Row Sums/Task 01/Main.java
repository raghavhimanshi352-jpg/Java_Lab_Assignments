// Name: Himanshi Raghav
// Roll Number: [Enter your roll number]
// Assignment 08 - Matrices Transpose and Row Sums
// Task 1

public class Main {
    public static void main(String[] args) {
        int[][] m = new int[3][4];
        int value = 1;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 4; j++) {
                m[i][j] = value++;
                System.out.print(m[i][j] + " ");
            }
            System.out.println();
        }
    }
}
