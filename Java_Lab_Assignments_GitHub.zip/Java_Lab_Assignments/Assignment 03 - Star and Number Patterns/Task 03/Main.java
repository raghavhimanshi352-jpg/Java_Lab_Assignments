// Name: Himanshi Raghav
// Roll Number: [Enter your roll number]
// Assignment 03 - Star and Number Patterns
// Task 3

public class Main {
    public static void main(String[] args) {
        for (int row = 1; row <= 4; row++) {
            for (int number = 1; number <= row; number++) {
                System.out.print(number + " ");
            }
            System.out.println();
        }
    }
}
