// Name: Himanshi Raghav
// Roll Number: [Enter your roll number]
// Assignment 03 - Star and Number Patterns
// Task 2

public class Main {
    public static void main(String[] args) {
        for (int row = 1; row <= 4; row++) {
            for (int col = 1; col <= row; col++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
