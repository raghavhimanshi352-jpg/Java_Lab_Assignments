// Name: Himanshi Raghav
// Roll Number: [Enter your roll number]
// Assignment 05 - Arrays Traversal and Counting
// Task 1

public class Main {
    public static void main(String[] args) {
        int[] arr = {3, 4, 5};
        for (int i = 0; i < arr.length; i++) {
            System.out.println("Index " + i + ": " + arr[i]);
        }
    }
}
